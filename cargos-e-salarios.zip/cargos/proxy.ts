import { NextResponse, type NextRequest } from "next/server";
import { COOKIE, tokenDaSenha } from "@/lib/auth";

export async function proxy(req: NextRequest) {
  const senha = process.env.APP_PASSWORD;
  if (!senha) return NextResponse.next();

  const { pathname } = req.nextUrl;
  if (pathname === "/login" || pathname === "/api/login") return NextResponse.next();

  const token = req.cookies.get(COOKIE)?.value;
  if (token && token === (await tokenDaSenha(senha))) return NextResponse.next();

  if (pathname.startsWith("/api/")) return NextResponse.json({ error: "Sessão expirada. Entre de novo." }, { status: 401 });
  const url = req.nextUrl.clone();
  url.pathname = "/login";
  return NextResponse.redirect(url);
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico|icon.svg).*)"] };
