export const COOKIE = "cs_sessao";

export async function tokenDaSenha(senha: string) {
  const bytes = new TextEncoder().encode(`cargos-e-salarios:${senha}`);
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(hash), (b) => b.toString(16).padStart(2, "0")).join("");
}
