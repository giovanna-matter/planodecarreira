import postgres from "postgres";

declare global {
  // eslint-disable-next-line no-var
  var __sql: ReturnType<typeof postgres> | undefined;
}

function connect() {
  const url = process.env.DATABASE_URL || process.env.POSTGRES_URL;
  if (!url) throw new Error("DATABASE_URL não configurada.");
  const local = /localhost|127\.0\.0\.1/.test(url);
  // prepare:false mantém compatibilidade com poolers (Neon/Supabase em modo transaction)
  return postgres(url, { ssl: local ? false : "require", max: 3, prepare: false, idle_timeout: 20 });
}

export function db() {
  if (!globalThis.__sql) globalThis.__sql = connect();
  return globalThis.__sql;
}
