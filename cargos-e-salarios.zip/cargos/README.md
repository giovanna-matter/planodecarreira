# Cargos e salários

Página interna (Next.js + Postgres) com o CRUD de cargos, faixas salariais e mobilidade entre cargos, montada a partir da planilha "Cargos e Salários".

## O que tem

- **Cargos e faixas**: lista agrupada por trilha, com uma régua salarial comum a todos os cargos. Filtros por área, nível e líder, e busca. Clicar num cargo abre a ficha completa (descrição, foco, requisitos, trilha vertical e mobilidades), com edição e exclusão.
- **Mobilidade entre cargos**: as trilhas horizontais da planilha (origem, destino, tipo e competências transferíveis), com criação, edição e exclusão.
- **Senha de acesso**: se `APP_PASSWORD` estiver definida, a página e a API pedem login.

As abas "Trilhas Verticais" e "Mapa de Carreiras" não viraram tabelas próprias porque são derivadas: a trilha vertical sai dos campos `familia` + `nivel` de cada cargo, e o mapa de carreiras sai da tabela de mobilidades.

## Deploy na Vercel

1. Suba esta pasta para um repositório no GitHub e importe o projeto na Vercel.
2. No projeto da Vercel, vá em **Storage → Create Database → Neon (Postgres)** e conecte ao projeto. Isso cria a variável `DATABASE_URL`.
3. Em **Settings → Environment Variables**, crie `APP_PASSWORD` com a senha de acesso.
4. No seu computador, dentro da pasta do projeto:
   ```bash
   npm install
   npx vercel link
   npx vercel env pull .env.local
   node --env-file=.env.local scripts/seed.mjs
   ```
   Isso cria as tabelas e importa os 67 cargos e 104 mobilidades. Rodar de novo não duplica nada; com `--reset` no final ele apaga e reimporta.
5. Faça o deploy (ou redeploy) na Vercel.

Funciona com qualquer Postgres (Supabase, Railway, local). No Supabase, use a string do pooler.

## Rodar localmente

```bash
cp .env.example .env.local   # preencha DATABASE_URL e APP_PASSWORD
npm install
node --env-file=.env.local scripts/seed.mjs
npm run dev
```

## Reimportar a planilha

Se a planilha mudar, gere o `data/seed.json` de novo e reimporte:

```bash
pip install openpyxl
python3 scripts/build_seed.py "Cargos e Salários.xlsx"
node --env-file=.env.local scripts/seed.mjs --reset
```

## Estrutura

```
app/page.tsx                 página principal (lê do banco no servidor)
app/login/page.tsx           tela de senha
app/api/cargos/...           GET, POST, PUT, DELETE de cargos
app/api/mobilidades/...      GET, POST, PUT, DELETE de mobilidades
components/App.tsx           interface (lista, régua, painel e formulários)
proxy.ts                     proteção por senha
db/schema.sql                tabelas
scripts/seed.mjs             cria tabelas e importa data/seed.json
scripts/build_seed.py        converte a planilha em data/seed.json
```
