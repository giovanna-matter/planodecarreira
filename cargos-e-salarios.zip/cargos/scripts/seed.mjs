// Cria as tabelas e carrega os dados da planilha (data/seed.json).
// Uso: DATABASE_URL=... node scripts/seed.mjs [--reset]
import postgres from "postgres";
import { readFileSync } from "node:fs";

const url = process.env.DATABASE_URL || process.env.POSTGRES_URL;
if (!url) {
  console.error("Defina DATABASE_URL antes de rodar o seed.");
  process.exit(1);
}
const sql = postgres(url, { ssl: url.includes("localhost") || url.includes("127.0.0.1") ? false : "require", max: 1 });
const reset = process.argv.includes("--reset");

try {
  if (reset) await sql`drop table if exists mobilidades, cargos`;
  await sql.unsafe(readFileSync(new URL("../db/schema.sql", import.meta.url), "utf8"));

  const [{ count }] = await sql`select count(*)::int as count from cargos`;
  if (count > 0) {
    console.log(`Banco já tem ${count} cargos. Nada foi importado (use --reset para recriar).`);
  } else {
    const seed = JSON.parse(readFileSync(new URL("../data/seed.json", import.meta.url), "utf8"));
    const cols = ["nome","position","familia","area","time","nivel","papel","lider","piso","teto","descricao","foco","complexidade","autonomia","requisitos"];
    await sql.begin(async (tx) => {
      await tx`insert into cargos ${tx(seed.cargos, cols)}`;
      const rows = await tx`select id, nome from cargos`;
      const ids = Object.fromEntries(rows.map((r) => [r.nome, r.id]));
      const mob = seed.mobilidades.map((m) => ({
        origem_id: ids[m.origem], destino_id: ids[m.destino], tipo: m.tipo || "Direta", observacao: m.observacao,
      }));
      await tx`insert into mobilidades ${tx(mob, "origem_id", "destino_id", "tipo", "observacao")} on conflict do nothing`;
    });
    console.log(`Importados ${seed.cargos.length} cargos e ${seed.mobilidades.length} mobilidades.`);
  }
} finally {
  await sql.end();
}
