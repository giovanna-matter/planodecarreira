import { NextResponse } from "next/server";
import { COOKIE, tokenDaSenha } from "@/lib/auth";

export async function POST(req: Request) {
  const senha = process.env.APP_PASSWORD;
  const form = await req.formData();
  const tentativa = String(form.get("senha") ?? "");
  const destino = new URL("/", req.url);

  if (!senha) return NextResponse.redirect(destino, 303);
  if (tentativa !== senha) return NextResponse.redirect(new URL("/login?erro=1", req.url), 303);

  const res = NextResponse.redirect(destino, 303);
  res.cookies.set(COOKIE, await tokenDaSenha(senha), {
    httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 24 * 30,
  });
  return res;
}

export async function DELETE() {
  const res = NextResponse.json({ ok: true });
  res.cookies.delete(COOKIE);
  return res;
}
