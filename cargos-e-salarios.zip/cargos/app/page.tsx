import { db } from "@/lib/db";
import type { Cargo, Mobilidade } from "@/lib/types";
import App from "@/components/App";

export const dynamic = "force-dynamic";

export default async function Page() {
  let cargos: Cargo[] = [];
  let mobilidades: Mobilidade[] = [];
  let erro: string | null = null;
  try {
    const sql = db();
    cargos = (await sql`select * from cargos order by familia nulls last, piso nulls last, nome`) as unknown as Cargo[];
    mobilidades = (await sql`select * from mobilidades order by id`) as unknown as Mobilidade[];
  } catch (e) {
    erro = e instanceof Error ? e.message : String(e);
  }

  if (erro) {
    return (
      <main className="setup">
        <h1>Falta conectar o banco</h1>
        <p>A página não conseguiu ler os cargos: <code>{erro}</code></p>
        <ol>
          <li>Na Vercel, abra o projeto, vá em Storage e conecte um banco Postgres (Neon). Isso cria a variável <code>DATABASE_URL</code>.</li>
          <li>No seu computador, rode <code>vercel env pull .env.local</code> e depois <code>npm run db:setup</code> para criar as tabelas e importar a planilha.</li>
          <li>Faça um novo deploy ou recarregue esta página.</li>
        </ol>
      </main>
    );
  }

  return <App initialCargos={JSON.parse(JSON.stringify(cargos))} initialMobilidades={JSON.parse(JSON.stringify(mobilidades))} temLogin={!!process.env.APP_PASSWORD} />;
}
