export default async function Login({ searchParams }: { searchParams: Promise<{ erro?: string }> }) {
  const { erro } = await searchParams;
  return (
    <main className="login">
      <form method="post" action="/api/login" className="login-card">
        <h1>Cargos e salários</h1>
        <p className="muted">Esta página tem faixas salariais. Digite a senha de acesso.</p>
        <label htmlFor="senha">Senha</label>
        <input id="senha" name="senha" type="password" autoFocus required autoComplete="current-password" />
        {erro && <p className="erro" role="alert">Senha incorreta. Confira e tente de novo.</p>}
        <button className="btn primary" type="submit">Entrar</button>
      </form>
    </main>
  );
}
