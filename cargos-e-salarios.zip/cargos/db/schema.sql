create table if not exists cargos (
  id           serial primary key,
  nome         text not null unique,
  position     text,
  familia      text,
  area         text,
  time         text,
  nivel        text not null default 'Júnior',
  papel        text,
  lider        text,
  piso         integer,
  teto         integer,
  descricao    text,
  foco         text,
  complexidade text,
  autonomia    text,
  requisitos   text,
  updated_at   timestamptz not null default now(),
  constraint faixa_valida check (piso is null or teto is null or piso <= teto)
);

create table if not exists mobilidades (
  id         serial primary key,
  origem_id  integer not null references cargos(id) on delete cascade,
  destino_id integer not null references cargos(id) on delete cascade,
  tipo       text not null default 'Direta',
  observacao text,
  unique (origem_id, destino_id),
  constraint origem_diferente check (origem_id <> destino_id)
);
